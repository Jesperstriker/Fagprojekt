package com.mmh.pkg;
import static org.junit.Assert.*;

import org.junit.Test;

public class TestTester {

	@Test
	public void tester(){
		
		int test = 1;
		assertEquals(test,1);
		
	}
	
}
